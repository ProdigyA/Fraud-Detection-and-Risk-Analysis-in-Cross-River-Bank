select * from customer_table;
select * from loan_table;
select * from transaction_table;

#Customer Risk Analysis: Identify customers with low credit scores and high-risk loans to predict potential defaults and prioritize risk mitigation strategies. BASIC
SELECT 
    customer_id, name, credit_score, risk_category
FROM
    customer_table
WHERE
    (credit_score < 500
        AND risk_category = 'HIGH')
ORDER BY credit_score DESC;

#Loan Purpose Insights: Determine the most popular loan purposes and their associated revenues to align financial products with customer demands. BASIC
SELECT 
    loan_purpose, 
    COUNT(*) AS total_loans, 
    SUM(loan_amount) AS total_revenue
FROM 
    loan_table
GROUP BY 
    loan_purpose
ORDER BY 
    total_loans DESC;

#High-Value Transactions: Detect transactions that exceed 30% of their respective loan amounts to fl ag potential fraudulent activities. BASIC
SELECT 
    t.transaction_id,
    t.customer_id,
    t.loan_id,
    t.transaction_date,
    t.transaction_amount,
    l.loan_amount,
    ROUND((t.transaction_amount * 1.0 / l.loan_amount) * 100, 2) AS transaction_percentage
FROM 
    transaction_table t
JOIN 
    loan_table l ON t.loan_id = l.loan_id
WHERE 
    t.transaction_amount > 0.3 * l.loan_amount
ORDER BY 
    transaction_percentage DESC;
    
    #Missed EMI Count: Analyze the number of missed EMIs per loan to identify loans at risk of default and suggest intervention strategies. BASIC
    SELECT 
    l.loan_id,
    c.customer_id,
    c.name AS customer_name,
    l.loan_amount,
    l.loan_status,
    l.repayment_history AS missed_emis
FROM 
    loan_table l
JOIN 
    customer_table c ON l.customer_id = c.customer_id
WHERE 
    l.repayment_history > 0
ORDER BY 
    missed_emis DESC;
    

#Regional Loan Distribution: Examine the geographical distribution of loan disbursements to assess regional trends and business opportunities. INTERMEDIATE

SELECT 
  SUBSTRING(address, CHAR_LENGTH(address) - 8 + 1, 3) AS region1,
  COUNT(l.loan_id) AS total_loans,
  SUM(l.loan_amount) AS total_loan_amount,
  AVG(l.loan_amount) AS avg_loan_amount
FROM 
  customer_table c
JOIN 
  loan_table l ON c.customer_id = l.customer_id
GROUP BY 
  region1
ORDER BY 
  total_loan_amount DESC;

select * from customer_table;

#Loyal Customers: List customers who have been associated with Cross River Bank for over five years and evaluate their loan activity to design loyalty programs.
SELECT 
  customer_id,
  name,
  credit_score,
  employment_status,
  risk_category,
  STR_TO_DATE(customer_since, '%d/%m/%Y') AS joined_date,
  TIMESTAMPDIFF(YEAR, STR_TO_DATE(customer_since, '%d/%m/%Y'), CURDATE()) AS years_with_bank
FROM 
  customer_table
WHERE 
  TIMESTAMPDIFF(YEAR, STR_TO_DATE(customer_since, '%d/%m/%Y'), CURDATE()) > 5;

#High-Performing Loans: Identify loans with excellent repayment histories to refine lending policies and highlight successful products. INTERMEDIA
SELECT *
FROM loan_table
JOIN customer_table ON loan_table.customer_id = customer_table.customer_id where loan_status = 'Approved';

#Age-Based Loan Analysis: Analyze loan amounts disbursed to customers of different age groups to design targeted fi nancial products. INTERMEDIATE
SELECT 
  CASE 
    WHEN c.age BETWEEN 18 AND 25 THEN '18-25'
    WHEN c.age BETWEEN 26 AND 35 THEN '26-35'
    WHEN c.age BETWEEN 36 AND 45 THEN '36-45'
    WHEN c.age BETWEEN 46 AND 55 THEN '46-55'
    WHEN c.age BETWEEN 56 AND 65 THEN '56-65'
    ELSE '65+' 
  END AS age_group,
  SUM(l.loan_amount) AS total_loan_amount,
  COUNT(l.loan_id) AS number_of_loans,
  AVG(l.loan_amount) AS avg_loan_amount,
  AVG(c.credit_score) AS avg_credit_score
FROM 
  loan_table l
JOIN 
  customer_table c ON l.customer_id = c.customer_id
GROUP BY 
  age_group
ORDER BY 
  age_group;
  
#Seasonal Transaction Trends: Examine transaction patterns over years and months to identify seasonal trends in loan repayments. Advanced
SELECT 
  YEAR(STR_TO_DATE(transaction_date, '%m/%d/%Y')) AS txn_year,
  MONTH(STR_TO_DATE(transaction_date, '%m/%d/%Y')) AS month_number,
  MONTHNAME(STR_TO_DATE(transaction_date, '%m/%d/%Y')) AS month_name,
  COUNT(*) AS repayment_count,
  SUM(transaction_amount) AS total_repayment
FROM 
  transaction_table
WHERE 
  LOWER(transaction_type) = 'EMI Payment'
GROUP BY 
  txn_year, month_number, month_name
ORDER BY 
  txn_year, month_number;

#Repayment History Analysis: Rank loans by repayment performance using window functions. Advanced

SELECT 
  loan_id,
  total_repaid,
  RANK() OVER (ORDER BY total_repaid DESC) AS repayment_rank
FROM (
  SELECT 
    loan_id,
    SUM(transaction_amount) AS total_repaid
  FROM 
    transaction_table
  WHERE 
    LOWER(transaction_type) = 'EMI Payment'
  GROUP BY 
    loan_id
) AS loan_repayments
ORDER BY repayment_rank;

#Credit Score vs. Loan Amount: Compare average loan amounts for different credit score ranges. Advanced
SELECT 
  CASE
    WHEN c.credit_score BETWEEN 300 AND 579 THEN 'Poor (300-579)'
    WHEN c.credit_score BETWEEN 580 AND 669 THEN 'Fair (580-669)'
    WHEN c.credit_score BETWEEN 670 AND 739 THEN 'Good (670-739)'
    WHEN c.credit_score BETWEEN 740 AND 799 THEN 'Very Good (740-799)'
    WHEN c.credit_score >= 800 THEN 'Excellent (800+)'
    ELSE 'Unknown'
  END AS credit_score_range,
  COUNT(DISTINCT c.customer_id) AS customer_count,
  COUNT(l.loan_id) AS total_loans,
  ROUND(AVG(l.loan_amount), 2) AS avg_loan_amount
FROM 
  customer_table c
JOIN 
  loan_table l ON c.customer_id = l.customer_id
GROUP BY 
  credit_score_range
ORDER BY 
  avg_loan_amount DESC;

#Top Borrowing Regions: Identify regions with the highest total loan disbursements. Advanced
SELECT 
  region1 AS region,
  COUNT(l.loan_id) AS total_loans,
  ROUND(SUM(l.loan_amount), 2) AS total_loan_disbursed,
  ROUND(AVG(l.loan_amount), 2) AS avg_loan_amount
FROM (
  SELECT 
    customer_id,
    SUBSTRING(address, CHAR_LENGTH(address) - 8 + 1, 3) AS region1
  FROM customer_table
) AS c
JOIN loan_table l ON c.customer_id = l.customer_id
GROUP BY region1
ORDER BY total_loan_disbursed DESC
LIMIT 10;


#Early Repayment Patterns: Detect loans with frequent early repayments and their impact on revenue. Advanced - Unable to solve





select * from customer_table;
select * from loan_table;
select * from transaction_table;


